ZAZA NATION ENTERTAINMENT WEBSITE
=================================

Files:
- index.html: responsive website
- assets/zaza-nation-logo.png: supplied logo

Preview:
Open index.html in a web browser.

Booking form:
The form opens WhatsApp with the enquiry pre-filled for +263 780 491 776.
The visitor still needs to press Send in WhatsApp. No information is stored by the website.

Before publishing:
1. Confirm the social media profile links in index.html.
2. Add official cover art, artist photos, music links and past-show photos.
3. Publish the folder using a static website host or connect a custom domain.
